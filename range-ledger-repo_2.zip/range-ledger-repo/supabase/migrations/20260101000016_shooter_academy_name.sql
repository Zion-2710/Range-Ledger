-- Captures the shooter's own stated academy name at signup — useful
-- alongside their coach name, especially when their coach hasn't
-- registered on the platform yet and there's no coaches.academy_name to
-- fall back on.
alter table students add column if not exists academy_name text;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  v_role text := new.raw_user_meta_data->>'role';
  v_coach_id uuid;
  v_national_qualified boolean;
  v_lane_reservation boolean;
  v_gst_percent numeric;
  v_specializations text[];
  v_teaching_disciplines text[];
begin
  begin
    v_coach_id := nullif(new.raw_user_meta_data->>'coach_id', '')::uuid;
  exception when others then
    v_coach_id := null;
  end;

  begin
    v_national_qualified := coalesce(nullif(new.raw_user_meta_data->>'national_qualified', '')::boolean, false);
  exception when others then
    v_national_qualified := false;
  end;

  begin
    v_lane_reservation := coalesce(nullif(new.raw_user_meta_data->>'lane_reservation', '')::boolean, false);
  exception when others then
    v_lane_reservation := false;
  end;

  begin
    v_gst_percent := coalesce(nullif(new.raw_user_meta_data->>'gst_percent', '')::numeric, 0);
  exception when others then
    v_gst_percent := 0;
  end;

  begin
    v_specializations := coalesce(
      array(select jsonb_array_elements_text(nullif(new.raw_user_meta_data->>'specializations', '')::jsonb)),
      '{}'
    );
  exception when others then
    v_specializations := '{}';
  end;

  begin
    v_teaching_disciplines := array(select jsonb_array_elements_text(nullif(new.raw_user_meta_data->>'teaching_disciplines', '')::jsonb));
  exception when others then
    v_teaching_disciplines := null;
  end;

  insert into public.profiles (id, role, name)
  values (new.id, coalesce(v_role, 'student'), coalesce(new.raw_user_meta_data->>'name', ''))
  on conflict (id) do nothing;

  if v_role = 'student' then
    insert into public.students (id, name, phone, email, category, shooter_category, coach_name, coach_id, national_qualified, nrai_shooter_id, nrai_email, academy_name)
    values (
      new.id,
      coalesce(new.raw_user_meta_data->>'name', ''),
      new.raw_user_meta_data->>'phone',
      new.email,
      coalesce(nullif(new.raw_user_meta_data->>'category', ''), 'Air Rifle 10m'),
      coalesce(nullif(new.raw_user_meta_data->>'shooter_category', ''), 'ISSF'),
      new.raw_user_meta_data->>'coach_name',
      v_coach_id,
      v_national_qualified,
      new.raw_user_meta_data->>'nrai_shooter_id',
      new.raw_user_meta_data->>'nrai_email',
      new.raw_user_meta_data->>'academy_name'
    )
    on conflict (id) do nothing;
  elsif v_role = 'coach' then
    insert into public.coaches (id, name, specialization, specializations, teaching_disciplines, academy_name, academy_address, lane_reservation, academy_upi_id, academy_gstin, gst_percent)
    values (
      new.id,
      coalesce(new.raw_user_meta_data->>'name', ''),
      coalesce(nullif(new.raw_user_meta_data->>'specialization', ''), 'Air Rifle 10m'),
      v_specializations,
      v_teaching_disciplines,
      new.raw_user_meta_data->>'academy_name',
      new.raw_user_meta_data->>'academy_address',
      v_lane_reservation,
      new.raw_user_meta_data->>'academy_upi_id',
      nullif(new.raw_user_meta_data->>'academy_gstin', ''),
      v_gst_percent
    )
    on conflict (id) do nothing;
  end if;

  return new;
exception when others then
  raise warning 'handle_new_user failed: % — %', sqlstate, sqlerrm;
  return new;
end;
$$;
